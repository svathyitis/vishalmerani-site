(() => {
 const guide=document.querySelector('.kitten-guide');if(!guide)return;
 const config=JSON.parse(document.getElementById('locale-config')?.textContent||'{}');
 const ui=config.ui||{},sections=config.sections||{};
 const button=guide.querySelector('button'),menu=guide.querySelector('.kitten-menu'),nav=menu.querySelector('nav');
 guide.querySelector('.kitten-title').textContent=ui.kitten||'Explore this page';
 button.setAttribute('aria-label',ui.kitten||'Explore this page');
 for(const [id,label] of Object.entries(sections)){
  if(!document.getElementById(id))continue;
  const a=document.createElement('a');a.href='#'+id;a.textContent=label;nav.append(a);
 }
 const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 let moodTimer,sceneTimer,scrollTimer,activeScene='',storyStarted=0;
 let audioContext;function purr(){if(reduced)return;try{audioContext=audioContext||new(window.AudioContext||window.webkitAudioContext)();const now=audioContext.currentTime;const osc=audioContext.createOscillator(),gain=audioContext.createGain();osc.type='sine';osc.frequency.setValueAtTime(68,now);osc.frequency.linearRampToValueAtTime(59,now+.8);gain.gain.setValueAtTime(.0001,now);gain.gain.exponentialRampToValueAtTime(.012,now+.1);gain.gain.exponentialRampToValueAtTime(.0001,now+.9);osc.connect(gain).connect(audioContext.destination);osc.start(now);osc.stop(now+.92)}catch(_){}}
 function setMood(mood,duration){if(reduced)return;guide.dataset.mood=mood;clearTimeout(moodTimer);if(duration)moodTimer=setTimeout(()=>{if(!activeScene)guide.dataset.mood='rest'},duration)}
 function close(){menu.hidden=true;button.setAttribute('aria-expanded','false')}
 button.addEventListener('click',()=>{purr();const next=menu.hidden;menu.hidden=!next;button.setAttribute('aria-expanded',String(next));if(next&& !activeScene)setMood('play',4200)});
 nav.addEventListener('click',e=>{if(e.target.closest('a'))close()});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')close()});
 document.addEventListener('click',e=>{if(!guide.contains(e.target))close()});
 let writing=false;
 function firstLetter(heading){
  const walker=document.createTreeWalker(heading,NodeFilter.SHOW_TEXT);
  while(walker.nextNode()){
   const text=walker.currentNode,value=text.textContent||'';
   const offset=value.search(/[^\s]/u);if(offset<0)continue;
   const range=document.createRange();range.setStart(text,offset);range.setEnd(text,offset+1);
   const rect=range.getBoundingClientRect();if(rect.width>2&&rect.height>2)return {glyph:value[offset],rect,heading};
  }
  return null;
 }
 function nearbyLetter(){
  const candidates=Array.from(document.querySelectorAll('.hero h1,.chapter h2,.future-courses h2,.scanning-sessions h2,.pain-waitlist h2,.teacher-interest h2,.corporate-training h2,.blessings-section h2'));
  const center=innerHeight*.47;
  return candidates.map(firstLetter).filter(Boolean).filter(c=>c.rect.top>60&&c.rect.bottom<innerHeight-60).sort((a,b)=>Math.abs(a.rect.top-center)-Math.abs(b.rect.top-center))[0];
 }
 function backgroundFor(el){
  let n=el;while(n&&n!==document.body){const bg=getComputedStyle(n).backgroundColor;if(bg&&bg!=='rgba(0, 0, 0, 0)'&&bg!=='transparent')return bg;n=n.parentElement}return getComputedStyle(document.body).backgroundColor||'#fff';
 }
 function wait(ms){return new Promise(resolve=>setTimeout(resolve,ms))}
 async function writeLetter(){
  if(writing||reduced)return;const found=nearbyLetter();if(!found)return;
  writing=true;close();clearTimeout(sceneTimer);activeScene='writing';
  const {rect,glyph,heading}=found;
  guide.dataset.scene='writing';guide.dataset.mood='walk';
  const x=Math.max(6,Math.min(innerWidth-72,rect.left+rect.width+8));
  const y=Math.max(70,Math.min(innerHeight-70,rect.bottom+5));
  guide.style.setProperty('--kitty-x',Math.round(x)+'px');guide.style.setProperty('--kitty-y',Math.round(y)+'px');
  const mark=document.createElement('span');mark.className='kitten-letter-mark';mark.setAttribute('aria-hidden','true');
  Object.assign(mark.style,{left:Math.floor(rect.left-2)+'px',top:Math.floor(rect.top-2)+'px',width:Math.ceil(rect.width+5)+'px',height:Math.ceil(rect.height+5)+'px',background:backgroundFor(heading),font:getComputedStyle(heading).font,color:getComputedStyle(heading).color,letterSpacing:getComputedStyle(heading).letterSpacing});
  const letter=document.createElement('span');letter.className='kitten-letter-ink';letter.textContent=glyph;mark.append(letter);document.body.append(mark);
  try{await wait(1100);guide.dataset.mood='erase';mark.classList.add('is-erased');await wait(550);guide.dataset.mood='write';mark.classList.add('is-writing');await wait(1450)}
  finally{mark.remove();writing=false;activeScene='';scene('');update()}
 }
 // An occasional unannounced tiny action when a heading is in view. Never interrupt forms.
 if(!reduced)setInterval(()=>{
  if(writing||activeScene==='sleep'||activeScene==='ashram'||document.hidden||document.activeElement?.closest('input,textarea,select,[contenteditable]'))return;
  if(nearbyLetter()&&Math.random()<.45)writeLetter();
 },48000);
 const email=document.querySelector('.top-contact a[href^="mailto:"]');
 const phone=document.querySelector('.top-contact a[href^="tel:"]');
 const sleep=document.querySelector('.kitten-station-sleep');
 const house=document.querySelector('.kitten-station-house'),food=document.querySelector('.kitten-station-food'),water=document.querySelector('.kitten-station-water'),sun=document.querySelector('.kitten-station-sun');
 const header=document.querySelector('.language-switch'),footer=document.querySelector('footer .footer-email');
 const sendButton=document.querySelector('#seva button[type=submit],#november-scanning button[type=submit],form button[type=submit]');
 const treePerch=document.querySelector('.tree-top-perch'),treeWindow=document.querySelector('.tree-window'),treeSwing=document.querySelector('.tree-swing'),treeClimb=document.querySelector('.tree-climb');
 const ashram=document.querySelector('.kitten-station-ashram'); const anchors={email,phone,sleep,ashram,house,food,water,sun,header,footer,sendButton,treePerch,treeWindow,treeSwing,treeClimb};
 let lastNibble=0;function nibble(){if(!food||Date.now()-lastNibble<15000)return;lastNibble=Date.now();food.classList.remove('is-nibbled');void food.offsetWidth;food.classList.add('is-nibbled');setTimeout(()=>food.classList.remove('is-nibbled'),3700)}
 const visible=el=>{if(!el)return false;const r=el.getBoundingClientRect();return r.bottom>80&&r.top<innerHeight-50};
 function place(el){
  const r=el.getBoundingClientRect(),w=guide.offsetWidth||65,h=guide.offsetHeight||60;
  // Stay just below and to the right of the relevant line, off its text if space allows.
  const station=['ashram','house','food','water','sun','treePerch','treeWindow','treeSwing','treeClimb'].includes(activeScene);
  const x=Math.min(innerWidth-w-8,Math.max(8,activeScene==='sun'?r.left+r.width*.22-w*.25:activeScene==='ashram'?r.left+r.width*.3:activeScene==='water'?r.left-w*.27:activeScene==='sleep'?r.left+r.width*.36:station?r.left-w*.42:r.right-w*.65));
  const y=Math.min(innerHeight-h-12,Math.max(85,activeScene==='sun'?r.top+r.height*.84-h*.75:activeScene==='water'?r.top+12:activeScene==='ashram'?r.top+58:activeScene==='sleep'?r.top+26:station?r.bottom-h*.22:r.bottom+5));
  guide.style.setProperty('--kitty-x',Math.round(x)+'px');guide.style.setProperty('--kitty-y',Math.round(y)+'px');
 }
 function scene(which){
  water?.classList.remove('is-drinking');clearTimeout(sceneTimer);activeScene=which;storyStarted=performance.now();
  if(!which){guide.removeAttribute('data-scene');guide.style.removeProperty('--kitty-x');guide.style.removeProperty('--kitty-y');setMood('rest');return}
  const el=anchors[which];if(!visible(el)){scene('');return}
  guide.dataset.scene=which;place(el);setMood('walk');
  if(which==='sleep'||which==='ashram'){storyStep();return}
  sceneTimer=setTimeout(()=>{if(activeScene===which){guide.dataset.mood=which==='sleep'||which==='house'?'sleep':'play';if(which==='ashram')guide.dataset.mood='kriya';if(which==='email')guide.dataset.mood='email';if(which==='phone')guide.dataset.mood='phone';if(which==='food'){guide.dataset.mood='nibble';nibble()}if(which==='water'){guide.dataset.mood='drink';water.classList.add('is-drinking')};if(which==='sendButton')guide.dataset.mood='scratch';if(which==='sun')guide.dataset.mood='sleep';if(which==='header'||which==='footer')guide.dataset.mood='play';if(which==='treeSwing')guide.dataset.mood='swing';if(which==='treeClimb')guide.dataset.mood='climb';if(which==='treePerch')guide.dataset.mood='sleep';if(which==='treeWindow')guide.dataset.mood='play'}},1300);
 }
 function storyStep(){
  const elapsed=(performance.now()-storyStarted)%18000;
  const el=anchors[activeScene];if(!el)return;
  let mood,label;
  if(activeScene==='sleep'){
   if(elapsed<2400){mood='walk';label='Time to rest'}
   else if(elapsed<5000){mood='settle';label='Getting cosy'}
   else if(elapsed<8000){mood='cover';label='Pulling up the blanket'}
   else{mood='sleep';label='Napping'}
  }else if(activeScene==='ashram'){
   if(elapsed<2400){mood='walk';label='Arriving at the ashram'}
   else if(elapsed<9000){mood='kriya';label='Learning Sudarshan Kriya'}
   else{mood='meditate';label='Now meditating'}
  }else return;
  if(reduced){mood=activeScene==='sleep'?'sleep':'meditate';label=activeScene==='sleep'?'Napping':'Now meditating'}
  guide.dataset.mood=mood;el.querySelector('.kitten-scene-caption').textContent=config.translate?.[label]||label;
 }
 function update(){
  if(activeScene==='writing')return;
  if(activeScene==='sleep'||activeScene==='ashram')storyStep();
  if(visible(sleep)){if(activeScene!=='sleep')scene('sleep');else place(sleep);return}
  if(visible(ashram)){if(activeScene!=='ashram')scene('ashram');else place(ashram);return}
  if(visible(house)){const target=['treeClimb','treePerch','treeSwing','treeWindow'][Math.floor(Date.now()/6500)%4];if(activeScene!==target)scene(target);else place(anchors[target]);return}
  if(visible(sendButton)&&Math.floor(Date.now()/19000)%4===1){if(activeScene!=='sendButton')scene('sendButton');else place(sendButton);return}
  for(const next of ['sun','water','food']){if(visible(anchors[next])){if(activeScene!==next)scene(next);else place(anchors[next]);return}}
  const options=['email','phone'].filter(which=>visible(anchors[which]));
  if(options.length){const next=options.length===2?(Math.floor(Date.now()/9000)%2?'phone':'email'):options[0];if(activeScene!==next)scene(next);else place(anchors[next]);return}
  const edge=visible(footer)?'footer':visible(header)?'header':null;
  if(edge){if(activeScene!==edge)scene(edge);else place(anchors[edge]);return}
  if(activeScene)scene('');
 }
 {
  guide.dataset.mood='rest';
  const moods=['play','sleep','play','rest'];let index=0;
  setInterval(()=>{if(activeScene)return;const m=moods[index++%moods.length];setMood(m,m==='rest'?0:6500)},12000);
  setInterval(update,900);
  let last=window.scrollY;window.addEventListener('scroll',()=>{
   if(Math.abs(window.scrollY-last)<60)return;last=window.scrollY;
   if(!activeScene){setMood('walk',1600);clearTimeout(scrollTimer);scrollTimer=setTimeout(()=>{if(!activeScene&&guide.dataset.mood==='walk')setMood('rest')},1700)}
   update();
  },{passive:true});
  window.addEventListener('resize',update,{passive:true});update();
 }
})();
