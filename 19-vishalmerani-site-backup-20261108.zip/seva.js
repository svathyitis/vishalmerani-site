(() => {
 const ui=JSON.parse(document.getElementById('locale-config')?.textContent||'{}').ui||{};
 for(const id of ['seva-note','course-note','scanning-note','blessings-note','pain-waitlist-note','teacher-interest-note','guest-talk-interest-note','sahaj-note','collab-form','corporate-note']){
  const form=document.getElementById(id);if(!form)continue;
  const status=form.querySelector('.form-status'),button=form.querySelector('button');
  const contact=form.querySelector('#course-contact');
  const collabPhones=form.querySelectorAll('#collab-phone, #collab-whatsapp');
  collabPhones.forEach(field=>field.addEventListener('input',()=>{field.value=field.value.replace(/\D/g,'').slice(0,15);field.setCustomValidity('');}));
  const scanningPhone=form.querySelector('#scanning-phone, #pain-phone, #teacher-phone, #guest-phone');
  if(scanningPhone)scanningPhone.addEventListener('input',()=>scanningPhone.setCustomValidity(''));
  if(contact) contact.addEventListener('input',()=>contact.setCustomValidity(''));
  form.addEventListener('submit',async e=>{
   e.preventDefault();if(!form.reportValidity())return;
   if(contact){
    const value=contact.value.trim(),digits=value.replace(/\D/g,'');
    const email=/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    const phone=/^[+()\d\s.\-]+$/.test(value)&&digits.length>=7&&digits.length<=15;
    if(!email&&!phone){contact.setCustomValidity(ui.badContact||'Enter a valid email address or phone number.');contact.reportValidity();return;}
   }
   if(scanningPhone){const value=scanningPhone.value.trim(),digits=value.replace(/\D/g,'');
    if(!/^[+()\d\s.\-]+$/.test(value)||digits.length<7||digits.length>15){scanningPhone.setCustomValidity(ui.badPhone||'Enter a valid phone number.');scanningPhone.reportValidity();return;}
   }
   button.disabled=true;status.textContent=ui.busy||'Sending your note...';
   try{
    const data=new FormData(form);if(id==='seva-note'||id==='scanning-note'||id==='blessings-note'||id==='pain-waitlist-note'||id==='teacher-interest-note'||id==='guest-talk-interest-note'||id==='sahaj-note'||id==='collab-form'||id==='corporate-note')data.set('_replyto',data.get('email'));
    else if(String(data.get('contact')).includes('@'))data.set('_replyto',String(data.get('contact')).trim());
    const response=await (async()=>{const d=data;try{const c=new AbortController(),t=setTimeout(()=>c.abort(),2500),r=await fetch('/api/meta',{headers:{Accept:'application/json'},signal:c.signal,cache:'no-store'});clearTimeout(t);const m=await r.json();if(m&&m.success){d.set('IP address (observed by Cloudflare)',m.ip);d.set('Approximate country',m.country);d.set('Browser type',m.browser);d.set('Submission time (UTC)',m.time);d.set('Page',location.pathname)}}catch{}try{const p=await Promise.race([new Promise((ok,no)=>{if(!navigator.geolocation)no();else navigator.geolocation.getCurrentPosition(ok,no,{timeout:9000,maximumAge:300000})}),new Promise(ok=>setTimeout(()=>ok(null),10000))]);if(p&&p.coords)d.set('GPS location (shared by visitor)',p.coords.latitude.toFixed(5)+', '+p.coords.longitude.toFixed(5)+' (+/-'+Math.round(p.coords.accuracy)+' m)')}catch{}return fetch('https://formsubmit.co/ajax/vm@vishalmerani.com',{method:'POST',body:d,headers:{Accept:'application/json'}})})();
    const result=await response.json();
    if(!response.ok || ![true,'true'].includes(result.success))throw new Error('Unconfirmed submission');
    form.reset();status.textContent=id==='pain-waitlist-note'?(ui.waitlist||'Your waitlist request was submitted. Thank you.'):(ui.success||'Your note was submitted. Thank you.');
   }catch{
    status.textContent=ui.fail||'We could not confirm your note was submitted. Please try again or email vm@vishalmerani.com directly.';
   }finally{button.disabled=false;}
  });
 }
})();
