/* Public official listing, fetched once per page visit. No login or tracking cookies sent. */
(async function(){
'use strict';
const box=document.querySelector('.programs-schedule');if(!box)return;
const source='https://www.artofliving.org/in-en/search-course';
const months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const parse=x=>{let m=String(x||'').match(/^(\d{4})-(\d\d)-(\d\d)/);if(m)return m.slice(1).join('-');m=String(x||'').match(/^(\d{1,2}) ([A-Za-z]{3}) (\d{4})/);if(!m)return null;const n=months.findIndex(a=>a.toLowerCase()===m[2].toLowerCase());return n<0?null:m[3]+'-'+String(n+1).padStart(2,'0')+'-'+m[1].padStart(2,'0')};
const label=(a,b)=>{let x=a.split('-').map(Number),y=b.split('-').map(Number);if(a===b)return x[2]+' '+months[x[1]-1]+' '+x[0];if(x[0]===y[0]&&x[1]===y[1])return x[2]+'–'+y[2]+' '+months[x[1]-1]+' '+x[0];return x[2]+' '+months[x[1]-1]+' '+x[0]+' – '+y[2]+' '+months[y[1]-1]+' '+y[0]};
const stamp=()=>new Intl.DateTimeFormat('en-IN',{day:'numeric',month:'short',year:'numeric',timeZone:'Asia/Kolkata'}).format(new Date());
// Keep a dated fallback if the official service is unavailable, but never show ended events.
box.querySelectorAll('.schedule-row').forEach(row=>{let date=row.querySelector('.schedule-date')?.textContent||'';let y=date.match(/(\d{4})$/),m=months.findIndex(x=>date.includes(x)),days=date.match(/\d+/g);if(y&&m>=0&&days){let end=y[1]+'-'+String(m+1).padStart(2,'0')+'-'+String(days.length>2?days[1]:days[0]).padStart(2,'0');if(end<today)row.remove()}});
const status=box.querySelector('.schedule-heading span');if(status)status.textContent='Checking official listing…';
const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
try{
const u=new URL(source);const future=(Number(today.slice(0,4))+1)+today.slice(4);
Object.entries({teacher_id:'t/vishal-merani',start_date_from:today,start_date_to:future,country:'in',type:'country',add_extra_info:'1',limit:'200','start-date-format':'02 Jan 2006','end-date-format':'02 Jan 2006'}).forEach(([k,v])=>u.searchParams.set(k,v));
const response=await fetch(u,{credentials:'omit',cache:'no-store',signal:controller.signal});if(!response.ok)throw Error('Listing unavailable');
const data=await response.json();if(!Array.isArray(data.courses)||Number(data.total)>data.courses.length)throw Error('Listing format changed or incomplete');
const rows=[];const seen=new Set();
for(const c of data.courses){
if(c.is_private===true||Number(c.is_private)===1)continue;
if(!Array.isArray(c.teachers)||!c.teachers.some(x=>String(x).trim().toLowerCase()==='vishal merani'))continue;
const start=parse(c.start_date),end=parse(c.end_date)||start;if(!start||!end)throw Error('Listing dates changed');if(end<today)continue;
const link=new URL(/^https?:\/\//.test(c.link)?c.link:'https://'+c.link);if(link.hostname!=='www.artofliving.org'||!link.pathname.startsWith('/in-en/program/'))throw Error('Unexpected event link');
if(seen.has(link.href))continue;seen.add(link.href);
let location=Number(c.is_online_event)===1?'Online':String(c.address_short||c.city||'See details');
let weekday=String(c.weekday_timings||'').replace(/\s+/g,' ').trim(),weekend=String(c.weekend_timings||'').replace(/\s+/g,' ').trim();
let timing=weekday&&weekend&&weekday!==weekend?'Weekdays '+weekday+'; weekends '+weekend:weekday||weekend;
if(c.is_complex_timing)timing='See details for session times';
let timezone=c.timezone==='Asia/Kolkata'?'IST':c.timezone||'';
const langs={en:'English',hi:'Hindi',kn:'Kannada',te:'Telugu',ta:'Tamil',mr:'Marathi',gu:'Gujarati',pa:'Punjabi',ml:'Malayalam',bn:'Bengali',ur:'Urdu'};
const language=Array.isArray(c.course_language)?c.course_language.map(x=>langs[x]||x).join(', '):'';
rows.push({start,html:'<a class="schedule-row" href="'+esc(link.href)+'" target="_blank" rel="noopener noreferrer"><span class="schedule-date">'+esc(label(start,end))+'</span><span class="schedule-place">'+esc(c.title)+'<small>'+esc([location,timing?timing+(timezone?' '+timezone:''):''].filter(Boolean).join(' · '))+'<br>'+esc(language||'')+'</small></span><span class="schedule-status">DETAILS <svg class="ui-arrow" viewBox="0 0 20 20" aria-hidden="true"><path d="M4 10h11m-5-5 5 5-5 5"/></svg></span></a>'});
}
rows.sort((a,b)=>a.start.localeCompare(b.start));
box.querySelectorAll('.schedule-row,.programs-message').forEach(x=>x.remove());
box.insertAdjacentHTML('beforeend',rows.length?rows.map(x=>x.html).join(''):'<p class="programs-message">No upcoming programs are currently listed. Please check back soon.</p>');
if(status)status.textContent='';
box.dataset.programsState='live';
}catch(error){
if(status)status.textContent='Saved list · checked 16 Oct 2026';
box.insertAdjacentHTML('beforeend','<p class="programs-message">The latest listing could not be loaded. Dates may have changed. <a href="https://www.artofliving.org/in-en/t/vishal-merani" target="_blank" rel="noopener noreferrer">Check the official listing</a>.</p>');
box.dataset.programsState='fallback';
}finally{clearTimeout(timer)}
})();
