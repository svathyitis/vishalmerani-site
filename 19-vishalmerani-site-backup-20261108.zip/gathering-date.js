(() => {
 const field=document.getElementById('gathering-event_date');
 if(!field)return;
 const localISO=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
 function limits(){
  const now=new Date(), start=new Date(now.getFullYear(),now.getMonth(),now.getDate());
  const maxDay=new Date(start.getFullYear(),start.getMonth()+5,0).getDate();
  const end=new Date(start.getFullYear(),start.getMonth()+4,Math.min(start.getDate(),maxDay));
  field.min=localISO(start);field.max=localISO(end);
  if(field.value && (field.value<field.min || field.value>field.max))field.value='';
 }
 limits();
 field.form?.addEventListener('submit', e=>{
  limits();
  if(!field.checkValidity()){e.preventDefault();field.reportValidity();}
 },true);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)limits()});
})();
