(async function(){
 const ui=JSON.parse(document.getElementById('locale-config')?.textContent||'{}').ui||{};
 const mount=document.getElementById('calendar-schedule');if(!mount)return;
 const lang=JSON.parse(document.getElementById('locale-config')?.textContent||'{}').lang||'en';
 const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const locales={hi:'hi-IN',te:'te-IN',kn:'kn-IN',en:'en-IN',ur:'ur-IN',pa:'pa-IN'};
 const paMonths=['ਜਨਵਰੀ','ਫ਼ਰਵਰੀ','ਮਾਰਚ','ਅਪ੍ਰੈਲ','ਮਈ','ਜੂਨ','ਜੁਲਾਈ','ਅਗਸਤ','ਸਤੰਬਰ','ਅਕਤੂਬਰ','ਨਵੰਬਰ','ਦਸੰਬਰ'];const monthFormat=lang==='pa'?{format:d=>paMonths[d.getUTCMonth()]+' '+d.getUTCFullYear()}:new Intl.DateTimeFormat(locales[lang]||'en-IN',{month:'short',year:'numeric',timeZone:'UTC'});
 const dayFormat=new Intl.DateTimeFormat(locales[lang]||'en-IN',{day:'numeric',timeZone:'UTC'});
  function dateLabel(e){if(lang==='en')return e.date;const start=new Date(e.start+'T12:00:00Z'),end=new Date(e.end+'T12:00:00Z');return start.getUTCMonth()===end.getUTCMonth()?dayFormat.format(start)+'–'+dayFormat.format(end)+' '+monthFormat.format(end):dayFormat.format(start)+' '+monthFormat.format(start)+' – '+dayFormat.format(end)+' '+monthFormat.format(end)}
 const titles={
 'Life, Death And The Journey Beyond & Art of Living Part 2':{hi:'जीवन, मृत्यु और उससे आगे की यात्रा एवं आर्ट ऑफ लिविंग भाग 2',te:'జీవితం, మరణం మరియు ఆవల ప్రయాణం & ఆర్ట్ ఆఫ్ లివింగ్ భాగం 2',kn:'ಜೀವನ, ಮರಣ ಮತ್ತು ಅದರಾಚೆಗಿನ ಪಯಣ ಮತ್ತು ಆರ್ಟ್ ಆಫ್ ಲಿವಿಂಗ್ ಭಾಗ 2'},
 'Discourse, Music, Meditation':{hi:'प्रवचन, संगीत, ध्यान',te:'ప్రవచనం, సంగీతం, ధ్యానం',kn:'ಪ್ರವಚನ, ಸಂಗೀತ, ಧ್ಯಾನ'},
 'Navaratri 2026':{hi:'नवरात्रि 2026',te:'నవరాత్రి 2026',kn:'ನವರಾತ್ರಿ 2026'},
 'A Journey To Egypt With Gurudev':{hi:'गुरुदेव के साथ मिस्र की यात्रा',te:'గురుదేవ్‌తో ఈజిప్టు యాత్ర',kn:'ಗುರುದೇವರೊಂದಿಗೆ ಈಜಿಪ್ಟ್ ಪಯಣ'},
 'Gurudev In Minsk':{hi:'मिन्स्क में गुरुदेव',te:'మిన్స్క్‌లో గురుదేవ్',kn:'ಮಿನ್ಸ್ಕ್‌ನಲ್ಲಿ ಗುರುದೇವರು'},
 'Gurudev In Munich – Live Sudarshan Kriya & Happiness Festival':{hi:'म्यूनिख में गुरुदेव - लाइव सुदर्शन क्रिया और हैपिनेस फ़ेस्टिवल',te:'మ్యూనిక్‌లో గురుదేవ్ - ప్రత్యక్ష సుదర్శన క్రియ & ఆనందోత్సవం',kn:'ಮ್ಯೂನಿಕ್‌ನಲ್ಲಿ ಗುರುದೇವರು - ನೇರ ಸುದರ್ಶನ ಕ್ರಿಯೆ ಮತ್ತು ಸಂತೋಷೋತ್ಸವ'},
 'Gurudev In Limassol':{hi:'लिमासोल में गुरुदेव',te:'లిమాసోల్‌లో గురుదేవ్',kn:'ಲಿಮಾಸೋಲ್‌ನಲ್ಲಿ ಗುರುದೇವರು'}};
 const cities={
 'Boone, North Carolina, United States':{hi:'बून, उत्तरी कैरोलिना, अमेरिका',te:'బూన్, నార్త్ కరోలినా, అమెరికా',kn:'ಬೂನ್, ನಾರ್ತ್ ಕ್ಯಾರೊಲೈನಾ, ಅಮೆರಿಕ'},
 'Bengaluru, Karnataka, India':{hi:'बेंगलुरु, कर्नाटक, भारत',te:'బెంగళూరు, కర్ణాటక, భారతదేశం',kn:'ಬೆಂಗಳೂರು, ಕರ್ನಾಟಕ, ಭಾರತ'},
 'Egypt':{hi:'मिस्र',te:'ఈజిప్టు',kn:'ಈಜಿಪ್ಟ್'},
 'Minsk, Belarus':{hi:'मिन्स्क, बेलारूस',te:'మిన్స్క్, బెలారస్',kn:'ಮಿನ್ಸ್ಕ್, ಬೆಲಾರಸ್'},
 'Munich, Germany':{hi:'म्यूनिख, जर्मनी',te:'మ్యూనిక్, జర్మనీ',kn:'ಮ್ಯೂನಿಕ್, ಜರ್ಮನಿ'},
 'Limassol, Cyprus':{hi:'लिमासोल, साइप्रस',te:'లిమాసోల్, సైప్రస్',kn:'ಲಿಮಾಸೋಲ್, ಸೈಪ್ರಸ್'}};
 const extra={"Life, Death And The Journey Beyond & Art of Living Part 2": {"ur": "زندگی، موت اور اس سے آگے کا سفر اور آرٹ آف لیونگ حصہ 2", "pa": "ਜੀਵਨ, ਮੌਤ ਅਤੇ ਉਸ ਤੋਂ ਅੱਗੇ ਦਾ ਸਫ਼ਰ ਅਤੇ ਆਰਟ ਆਫ਼ ਲਿਵਿੰਗ ਭਾਗ 2"}, "Discourse, Music, Meditation": {"ur": "گفتگو، موسیقی، مراقبہ", "pa": "ਪ੍ਰਵਚਨ, ਸੰਗੀਤ, ਧਿਆਨ"}, "Navaratri 2026": {"ur": "نوراتری 2026", "pa": "ਨਵਰਾਤਰੀ 2026"}, "A Journey To Egypt With Gurudev": {"ur": "گرو دیو کے ساتھ مصر کا سفر", "pa": "ਗੁਰੂਦੇਵ ਨਾਲ ਮਿਸਰ ਦਾ ਸਫ਼ਰ"}, "Gurudev In Minsk": {"ur": "منسک میں گرو دیو", "pa": "ਮਿੰਸਕ ਵਿੱਚ ਗੁਰੂਦੇਵ"}, "Gurudev In Munich – Live Sudarshan Kriya & Happiness Festival": {"ur": "میونخ میں گرو دیو - براہِ راست سدرشن کریا اور خوشی کا میلہ", "pa": "ਮਿਊਨਿਖ ਵਿੱਚ ਗੁਰੂਦੇਵ - ਲਾਈਵ ਸੁਦਰਸ਼ਨ ਕਿਰਿਆ ਅਤੇ ਖੁਸ਼ੀ ਦਾ ਮੇਲਾ"}, "Gurudev In Limassol": {"ur": "لیماسول میں گرو دیو", "pa": "ਲਿਮਾਸੋਲ ਵਿੱਚ ਗੁਰੂਦੇਵ"}, "Boone, North Carolina, United States": {"ur": "بون، شمالی کیرولائنا، امریکہ", "pa": "ਬੂਨ, ਨੌਰਥ ਕੈਰੋਲੀਨਾ, ਅਮਰੀਕਾ"}, "Bengaluru, Karnataka, India": {"ur": "بنگلورو، کرناٹک، بھارت", "pa": "ਬੈਂਗਲੁਰੂ, ਕਰਨਾਟਕ, ਭਾਰਤ"}, "Egypt": {"ur": "مصر", "pa": "ਮਿਸਰ"}, "Minsk, Belarus": {"ur": "منسک، بیلاروس", "pa": "ਮਿੰਸਕ, ਬੇਲਾਰੂਸ"}, "Munich, Germany": {"ur": "میونخ، جرمنی", "pa": "ਮਿਊਨਿਖ, ਜਰਮਨੀ"}, "Limassol, Cyprus": {"ur": "لیماسول، قبرص", "pa": "ਲਿਮਾਸੋਲ, ਸਾਈਪ੍ਰਸ"}};const localized=(table,raw)=>extra[raw]?.[lang]||table[raw]?.[lang]||raw;
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
 const decode=s=>{const d=document.createElement('textarea');d.innerHTML=String(s||'');return d.value};
 const formatDate=(start,end)=>{const months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];let a=start.split('-').map(Number),b=end.split('-').map(Number);if(start===end)return a[2]+' '+months[a[1]-1]+' '+a[0];return a[0]===b[0]&&a[1]===b[1]?a[2]+'–'+b[2]+' '+months[b[1]-1]+' '+b[0]:a[2]+' '+months[a[1]-1]+(a[0]!==b[0]?' '+a[0]:'')+'–'+b[2]+' '+months[b[1]-1]+' '+b[0]};
 const checkedLabel=date=>lang==='en'?date:lang==='pa'?(()=>{const d=new Date(date+'T12:00:00Z');return d.getUTCDate()+' '+monthFormat.format(d)})():new Intl.DateTimeFormat(locales[lang]||'en-IN',{day:'numeric',month:'short',year:'numeric',timeZone:'UTC'}).format(new Date(date+'T12:00:00Z'));
 const messages={en:['Updated','Saved list','The latest schedule could not be loaded. Dates may have changed.','No upcoming events are currently listed.','View the official calendar'],hi:['अपडेट किया गया','सहेजी गई सूची','नवीनतम कार्यक्रम लोड नहीं हो सका। तारीखें बदल सकती हैं।','अभी कोई आगामी कार्यक्रम सूचीबद्ध नहीं है।','आधिकारिक कैलेंडर देखें'],te:['నవీకరించబడింది','సేవ్ చేసిన జాబితా','తాజా షెడ్యూల్ లోడ్ కాలేదు. తేదీలు మారి ఉండవచ్చు.','ప్రస్తుతం రాబోయే కార్యక్రమాలు లేవు.','అధికారిక క్యాలెండర్ చూడండి'],kn:['ನವೀಕರಿಸಲಾಗಿದೆ','ಉಳಿಸಿದ ಪಟ್ಟಿ','ಇತ್ತೀಚಿನ ವೇಳಾಪಟ್ಟಿ ಲೋಡ್ ಆಗಲಿಲ್ಲ. ದಿನಾಂಕಗಳು ಬದಲಾಗಿರಬಹುದು.','ಪ್ರಸ್ತುತ ಮುಂಬರುವ ಕಾರ್ಯಕ್ರಮಗಳಿಲ್ಲ.','ಅಧಿಕೃತ ಕ್ಯಾಲೆಂಡರ್ ನೋಡಿ'],ur:['تازہ کاری','محفوظ فہرست','تازہ شیڈول لوڈ نہیں ہو سکا۔ تاریخیں بدل سکتی ہیں۔','فی الحال کوئی آنے والا پروگرام درج نہیں ہے۔','سرکاری کیلنڈر دیکھیں'],pa:['ਅੱਪਡੇਟ ਕੀਤਾ','ਸੰਭਾਲੀ ਸੂਚੀ','ਨਵਾਂ ਸ਼ਡਿਊਲ ਲੋਡ ਨਹੀਂ ਹੋ ਸਕਿਆ। ਤਾਰੀਖਾਂ ਬਦਲ ਸਕਦੀਆਂ ਹਨ।','ਇਸ ਵੇਲੇ ਕੋਈ ਆਉਣ ਵਾਲਾ ਸਮਾਗਮ ਨਹੀਂ ਹੈ।','ਅਧਿਕਾਰਤ ਕੈਲੰਡਰ ਵੇਖੋ']}[lang]||['Updated','Saved list','The latest schedule could not be loaded. Dates may have changed.','No upcoming events are currently listed.','View the official calendar'];
 function render(data,live){
 const events=data.events.filter(e=>e.end>=today).sort((a,b)=>a.start.localeCompare(b.start)).slice(0,12);
 let head='<div class="schedule-heading"><strong>'+esc(ui.official||'ON THE OFFICIAL SCHEDULE')+'</strong><span>'+(live?'':esc(messages[1]+' · '+(ui.checked||'Checked'))+' '+esc(checkedLabel(data.checkedOn)))+'</span></div>';
 const rows=events.map(e=>{let active=e.start<=today&&e.end>=today;return '<a class="schedule-row'+(active?' is-current':'')+'" href="'+esc(e.url)+'" target="_blank" rel="noopener noreferrer"><span class="schedule-date">'+esc(dateLabel(e))+'</span><span class="schedule-place">'+esc(localized(cities,e.city))+'<small>'+esc(localized(titles,e.title))+'</small></span><span class="schedule-status">'+(active?(ui.current||'THIS WEEK'):(ui.next||'UP NEXT'))+' <svg class="ui-arrow" viewBox="0 0 20 20" aria-hidden="true"><path d="M4 10h11m-5-5 5 5-5 5"/></svg></span></a>'}).join('');
 const link='<a href="https://gurudev.artofliving.org/tour-schedule/" target="_blank" rel="noopener noreferrer">'+esc(messages[4])+'</a>';
 mount.innerHTML=head+rows+(events.length?'':'<p>'+esc(messages[3])+'</p>')+(!live?'<p class="schedule-refresh-note">'+esc(messages[2])+' '+link+'</p>':'');mount.dataset.scheduleState=live?'live':'fallback';
 }
 // Render the dated saved list first. Live success replaces it; failures leave an explicit warning.
 let saved=null;
 try{const r=await fetch('/gurudev-schedule.json',{cache:'no-cache'});if(!r.ok)throw Error();saved=await r.json();render(saved,false)}catch{mount.innerHTML='<p>'+esc(ui.unavailable||messages[2])+' <a href="https://gurudev.artofliving.org/tour-schedule/" target="_blank" rel="noopener noreferrer">'+esc(messages[4])+'</a></p>';mount.dataset.scheduleState='unavailable'}
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
 try{
 const u=new URL('https://gurudev.artofliving.org/wp-json/tribe/events/v1/events');
 Object.entries({per_page:'100',start_date:'2000-01-01',ends_after:today,end_date:(Number(today.slice(0,4))+2)+today.slice(4),wpml_language:'en'}).forEach(([k,v])=>u.searchParams.set(k,v));
 const response=await fetch(u,{credentials:'omit',cache:'no-store',signal:controller.signal});if(!response.ok)throw Error('Official schedule unavailable');
 const data=await response.json();if(!Array.isArray(data.events)||Number(data.total)>data.events.length)throw Error('Schedule incomplete');
 const events=[];const seen=new Set();
 for(const e of data.events){
 if(e.status!=='publish')continue;
 const start=String(e.start_date||'').slice(0,10),end=String(e.end_date||'').slice(0,10);if(!/^\d{4}-\d{2}-\d{2}$/.test(start)||!/^\d{4}-\d{2}-\d{2}$/.test(end)||end<start)throw Error('Invalid schedule dates');if(end<today)continue;
 const url=new URL(e.url);if(url.hostname!=='gurudev.artofliving.org'||url.protocol!=='https:'||!url.pathname.startsWith('/tour-schedule/'))throw Error('Unexpected event link');if(seen.has(url.href))continue;seen.add(url.href);
 const venue=e.venue||{};const city=[venue.city||venue.venue,venue.stateprovince||venue.province,venue.country].filter(Boolean).map(decode).filter((x,i,a)=>a.indexOf(x)===i).join(', ');
 events.push({start,end,date:formatDate(start,end),title:decode(e.title),city,url:url.href});
 }
 render({events,checkedOn:today},true);
 }catch{if(saved)render(saved,false)}finally{clearTimeout(timer)}
})();
